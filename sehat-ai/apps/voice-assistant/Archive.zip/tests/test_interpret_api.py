"""API tests use mocked audio and Qwen; no model downloads or patient data."""

import importlib.util
import sys
import types
from unittest.mock import patch

from fastapi.testclient import TestClient

# CI can test request handling without loading the large ASR model.
if importlib.util.find_spec("faster_whisper") is None:
    mock_whisper = types.ModuleType("faster_whisper")
    mock_whisper.WhisperModel = object
    sys.modules["faster_whisper"] = mock_whisper

from app.api.voice_assistant import interpretation  # noqa: E402
from app.contracts.transcription import TranscriptionResult  # noqa: E402
from app.main import app  # noqa: E402
from app.services.extraction.ai_interpreter import ModelAnswer, Proposal  # noqa: E402

URL = "/api/voice-assistant/interpret"
FORM = {"form_id": "patient_registration", "section_id": "personal_details"}
client = TestClient(app)


class DummySTT:
    def __init__(self, text="Gender Female"):
        self.text = text

    async def transcribe(self, audio, filename, content_type):
        return TranscriptionResult(text=self.text, language="en")


def send(audio=b"nonpatient-example", mime="audio/webm", fields=None):
    return client.post(
        URL,
        data=fields or FORM,
        files={"file": ("sample.webm", audio, mime)},
    )


def test_disabled_by_default(monkeypatch):
    monkeypatch.delenv("SEHAT_INTERPRET_ENABLED", raising=False)
    assert send().status_code == 404


def test_extracts_reviewable_field(monkeypatch):
    monkeypatch.setenv("SEHAT_INTERPRET_ENABLED", "1")
    with patch.object(interpretation, "get_stt_provider", return_value=DummySTT()), patch(
        "app.services.extraction.ai_interpreter.ask_qwen",
        return_value=ModelAnswer(proposals=[Proposal(name="gender", spoken="Female", value="Female")]),
    ):
        result = send()
    assert result.status_code == 200
    assert result.json()["fields"]["gender"]["value"] == "Female"
    assert result.json()["requires_review"] is True


def test_rejects_bad_audio(monkeypatch):
    monkeypatch.setenv("SEHAT_INTERPRET_ENABLED", "1")
    assert send(mime="application/x-msdownload").status_code == 415
    assert send(audio=b"").status_code == 400
    assert send(audio=b"a" * (10 * 1024 * 1024 + 1)).status_code == 413


def test_rejects_unknown_schema(monkeypatch):
    monkeypatch.setenv("SEHAT_INTERPRET_ENABLED", "1")
    fields = {"form_id": "patient_registration", "section_id": "not_a_section"}
    assert send(fields=fields).status_code == 404


def test_rejects_silence_and_long_transcript(monkeypatch):
    monkeypatch.setenv("SEHAT_INTERPRET_ENABLED", "1")
    with patch.object(interpretation, "get_stt_provider", return_value=DummySTT(" ")):
        assert send().status_code == 422
    with patch.object(interpretation, "get_stt_provider", return_value=DummySTT("x" * 5001)):
        assert send().status_code == 422


def test_model_outage_is_safe(monkeypatch):
    monkeypatch.setenv("SEHAT_INTERPRET_ENABLED", "1")
    with patch.object(interpretation, "get_stt_provider", return_value=DummySTT()), patch(
        "app.services.extraction.ai_interpreter.ask_qwen", side_effect=TimeoutError("internal URL")
    ):
        response = send()
    assert response.status_code == 503
    assert "internal URL" not in response.text
