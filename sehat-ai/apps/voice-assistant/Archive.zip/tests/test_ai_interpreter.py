"""Unit tests for model output validation (no network or model download)."""

from unittest.mock import patch

from app.services.extraction.ai_interpreter import (
    ModelAnswer,
    Proposal,
    interpret_transcript,
)

FORM = "patient_registration"
SECTION = "personal_details"


def extract(transcript: str, *proposals: Proposal):
    with patch(
        "app.services.extraction.ai_interpreter.ask_qwen",
        return_value=ModelAnswer(proposals=list(proposals)),
    ):
        return interpret_transcript(transcript, FORM, SECTION)


def test_spoken_digits_keep_leading_zero():
    transcript = "Phone number zero double three one two three four five six seven eight"
    result = extract(transcript, Proposal(
        name="phone_number",
        spoken="zero double three one two three four five six seven eight",
        value="03312345678",
    ))
    assert result.fields["phone_number"].value == "03312345678"
    assert result.requires_review is True


def test_bad_phone_never_autofills():
    result = extract("phone number double three", Proposal(
        name="phone_number", spoken="double three", value="33"
    ))
    assert "phone_number" not in result.fields
    assert result.unresolved[0].field_name == "phone_number"


def test_reference_returns_spoken_name_not_invented_id():
    result = extract("District Sakhar", Proposal(
        name="district_id", spoken="Sakhar", value="Sukkur"
    ))
    assert result.references["district_id"].spoken_label == "Sakhar"
    assert result.references["district_id"].resolved_id is None


def test_enum_is_exactly_one_allowed_option():
    result = extract("Gender Female", Proposal(
        name="gender", spoken="Female", value="Female"
    ))
    assert result.fields["gender"].value == "Female"


def test_unsupported_enum_is_unresolved():
    result = extract("Gender unspecified", Proposal(
        name="gender", spoken="unspecified", value="unspecified"
    ))
    assert "gender" not in result.fields
    assert result.unresolved[0].field_name == "gender"


def test_hallucinated_evidence_never_applies():
    result = extract("First name Rabia", Proposal(
        name="first_name", spoken="Ali", value="Ali"
    ))
    assert "first_name" not in result.fields
    assert result.unresolved


def test_invented_field_name_is_ignored():
    result = extract("My diagnosis is fever", Proposal(
        name="diagnosis", spoken="fever", value="fever"
    ))
    assert not result.fields and not result.references


def test_conflicting_proposals_never_apply():
    result = extract("First name Ali then Ahmed", Proposal(
        name="first_name", spoken="Ali", value="Ali"
    ), Proposal(name="first_name", spoken="Ahmed", value="Ahmed"))
    assert "first_name" not in result.fields
    assert result.unresolved


def test_urdu_numbers_need_model_not_word_lookup():
    result = extract("phone number zero teen teen aik do teen chaar paanch chay saat aath", Proposal(
        name="phone_number",
        spoken="zero teen teen aik do teen chaar paanch chay saat aath",
        value="03312345678",
    ))
    assert result.fields["phone_number"].value == "03312345678"
